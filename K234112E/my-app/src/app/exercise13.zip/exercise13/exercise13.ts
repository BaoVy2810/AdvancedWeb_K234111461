import { Component } from '@angular/core';

@Component({
  selector: 'app-exercise13',
  standalone: false,
  templateUrl: './exercise13.html',
  styleUrl: './exercise13.css',
})
export class Exercise13 {
  constructor() { }
}
