import { Component } from '@angular/core';

@Component({
  selector: 'app-list-product-component',
  standalone: false,
  templateUrl: './list-product-component.html',
  styleUrl: './list-product-component.css',
})
export class ListProductComponent {

}
