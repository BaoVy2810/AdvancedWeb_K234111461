import { Component } from '@angular/core';

@Component({
  selector: 'app-exercise19',
  standalone: false,
  templateUrl: './exercise19.html',
  styleUrl: './exercise19.css',
})
export class Exercise19 {

}
