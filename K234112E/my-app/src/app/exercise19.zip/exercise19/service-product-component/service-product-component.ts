import { Component } from '@angular/core';

@Component({
  selector: 'app-service-product-component',
  standalone: false,
  templateUrl: './service-product-component.html',
  styleUrl: './service-product-component.css',
})
export class ServiceProductComponent {

}
